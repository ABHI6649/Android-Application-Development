package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.CalculatorEngine
import com.example.model.ConversionUnit
import com.example.model.StopwatchFormatter
import com.example.model.UnitCategory
import com.example.model.UnitRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import com.example.viewmodel.ConverterViewModel

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun readStringFromContext() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Utility Suite", appName)
  }

  @Test
  fun unitConverter_lengthConversion() {
    val meters = ConversionUnit("m", "Metres", "m", UnitCategory.LENGTH, 1.0)
    val centimeters = ConversionUnit("cm", "Centimetres", "cm", UnitCategory.LENGTH, 0.01)

    val result = UnitRepository.convert(2.5, meters, centimeters)
    assertEquals(250.0, result, 0.001)
  }

  @Test
  fun unitConverter_temperatureConversion() {
    val celsius = ConversionUnit("c", "Celsius", "°C", UnitCategory.TEMPERATURE)
    val fahrenheit = ConversionUnit("f", "Fahrenheit", "°F", UnitCategory.TEMPERATURE)

    val result = UnitRepository.convert(100.0, celsius, fahrenheit)
    assertEquals(212.0, result, 0.001)
  }

  @Test
  fun unitConverter_areaConversion() {
    val sqKm = ConversionUnit("sqkm", "Square Kilometres", "km²", UnitCategory.AREA, 1_000_000.0)
    val sqM = ConversionUnit("sqm", "Square Metres", "m²", UnitCategory.AREA, 1.0)

    val result = UnitRepository.convert(1.5, sqKm, sqM)
    assertEquals(1_500_000.0, result, 0.001)
  }

  @Test
  fun unitConverter_dataConversion() {
    val gigabytes = ConversionUnit("gb", "Gigabytes (GB)", "GB", UnitCategory.DATA, 1073741824.0)
    val megabytes = ConversionUnit("mb", "Megabytes (MB)", "MB", UnitCategory.DATA, 1048576.0)

    val result = UnitRepository.convert(2.0, gigabytes, megabytes)
    assertEquals(2048.0, result, 0.001)
  }

  @Test
  fun calculatorEngine_precedenceAndArithmetic() {
    val result = CalculatorEngine.evaluate("2+3×4")
    assertTrue(result.isSuccess)
    assertEquals("14", result.getOrNull())
  }

  @Test
  fun calculatorEngine_divisionByZero() {
    val result = CalculatorEngine.evaluate("10÷0")
    assertTrue(result.isFailure)
  }

  @Test
  fun stopwatchFormatter_formatCentiseconds() {
    val formatted = StopwatchFormatter.formatTime(65430L)
    assertEquals("01:05", formatted.primaryDigits)
    assertEquals(".43", formatted.fractionDigits)
  }

  @Test
  fun converterViewModel_computesResultSuccessfully() {
    val viewModel = ConverterViewModel()
    // Initial state: 1 cm to m = 0.01 m
    assertTrue(viewModel.uiState.value.resultFormatted.isNotEmpty())
    assertEquals("0.01", viewModel.uiState.value.resultFormatted)

    // Update value and convert: 5 cm to m = 0.05 m
    viewModel.onInputValueChanged("5")
    viewModel.onConvertClicked()
    assertEquals("0.05", viewModel.uiState.value.resultFormatted)
  }
}
