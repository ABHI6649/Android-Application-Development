package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Modern Indigo & Cyan Palette
val IndigoPrimary = Color(0xFF4F46E5)
val IndigoOnPrimary = Color(0xFFFFFFFF)
val IndigoContainer = Color(0xFFE0E7FF)
val IndigoOnContainer = Color(0xFF1E1B4B)

val CyanSecondary = Color(0xFF06B6D4)
val CyanOnSecondary = Color(0xFFFFFFFF)
val CyanContainer = Color(0xFFCFFAFE)
val CyanOnContainer = Color(0xFF164E63)

val AmberTertiary = Color(0xFFF59E0B)
val AmberOnTertiary = Color(0xFFFFFFFF)
val AmberContainer = Color(0xFFFEF3C7)
val AmberOnContainer = Color(0xFF78350F)

val NeutralDark = Color(0xFF0F172A)
val NeutralSurfaceDark = Color(0xFF1E293B)
val NeutralSurfaceDarkHigh = Color(0xFF334155)

val NeutralLight = Color(0xFFF8FAFC)
val NeutralSurfaceLight = Color(0xFFFFFFFF)
val NeutralSurfaceLightHigh = Color(0xFFF1F5F9)

// Dark Theme Variants
val IndigoPrimaryDark = Color(0xFF818CF8)
val IndigoContainerDark = Color(0xFF312E81)
val CyanSecondaryDark = Color(0xFF38BDF8)
val CyanContainerDark = Color(0xFF0C4A6E)
val AmberTertiaryDark = Color(0xFFFBBF24)
val AmberContainerDark = Color(0xFF78350F)
