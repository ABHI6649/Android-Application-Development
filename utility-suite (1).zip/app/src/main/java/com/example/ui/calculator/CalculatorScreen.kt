package com.example.ui.calculator

import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.CalculatorUiState
import com.example.viewmodel.CalculatorViewModel

// iOS Calculator standard color palette
private val IosBlackBackground = Color(0xFF000000)
private val IosNumberGray = Color(0xFF333333)
private val IosNumberGrayPressed = Color(0xFF737373)
private val IosFunctionLightGray = Color(0xFFA5A5A5)
private val IosFunctionLightGrayPressed = Color(0xFFD9D9D9)
private val IosOperatorOrange = Color(0xFFFF9F0A)
private val IosOperatorActiveWhite = Color(0xFFFFFFFF)
private val IosOperatorPressed = Color(0xFFCC7F08)
private val IosTextDark = Color(0xFF000000)
private val IosTextWhite = Color(0xFFFFFFFF)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    viewModel: CalculatorViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    var showHistorySheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState()
    val view = LocalView.current

    val triggerHaptic = {
        try {
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        } catch (_: Exception) {}
    }

    // Determine current clear button label (AC if empty or reset, C if active typing)
    val clearLabel = if (state.expression.isEmpty()) "AC" else "C"

    // Primary display text: if evaluated, show preview result; if typing, show expression or 0
    val displayText = when {
        state.isEvaluated && state.previewResult.isNotEmpty() -> state.previewResult
        state.expression.isNotEmpty() -> state.expression
        else -> "0"
    }

    // Dynamic typography scaling based on length just like iOS
    val displayFontSize = when {
        displayText.length <= 6 -> 74.sp
        displayText.length <= 8 -> 60.sp
        displayText.length <= 11 -> 46.sp
        displayText.length <= 15 -> 36.sp
        else -> 28.sp
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(IosBlackBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            // iOS-style top toolbar with subtle History button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Calculator",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF8E8E93)
                )

                IconButton(
                    onClick = {
                        triggerHaptic()
                        showHistorySheet = true
                    },
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1C1C1E))
                        .testTag("calculator_history_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Calculation History",
                        tint = Color(0xFF8E8E93),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // iOS Display Area with swipe-to-backspace gesture
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures { _, dragAmount ->
                            if (dragAmount < -20 || dragAmount > 20) {
                                triggerHaptic()
                                viewModel.onBackspace()
                            }
                        }
                    },
                horizontalAlignment = Alignment.End
            ) {
                // Secondary preview/expression indicator if in progress
                if (state.isEvaluated && state.expression.isNotEmpty()) {
                    Text(
                        text = state.expression,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(0xFF8E8E93),
                        textAlign = TextAlign.End,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 4.dp)
                    )
                } else if (!state.isEvaluated && state.previewResult.isNotEmpty() && state.previewResult != "Error") {
                    Text(
                        text = "= ${state.previewResult}",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color(0xFF8E8E93),
                        textAlign = TextAlign.End,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 4.dp)
                            .testTag("calculator_result_display")
                    )
                }

                // Main Display Text with iOS ultra-clean thin/light styling
                Text(
                    text = displayText,
                    fontSize = displayFontSize,
                    fontWeight = FontWeight.Light,
                    color = if (state.hasError) Color(0xFFFF453A) else IosTextWhite,
                    textAlign = TextAlign.End,
                    lineHeight = displayFontSize,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("calculator_expression_display")
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Keypad: Classic iPhone 5-row layout with circular buttons
            val buttonSpacing = 12.dp

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(buttonSpacing)
            ) {
                // Row 1: AC/C, ±, %, ÷
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(buttonSpacing)
                ) {
                    IosCalcButton(
                        text = clearLabel,
                        buttonType = IosButtonType.FUNCTION,
                        modifier = Modifier.weight(1f),
                        testTag = "btn_clear",
                        onClick = {
                            triggerHaptic()
                            viewModel.onClear()
                        }
                    )
                    IosCalcButton(
                        text = "±",
                        buttonType = IosButtonType.FUNCTION,
                        modifier = Modifier.weight(1f),
                        testTag = "btn_negate",
                        onClick = {
                            triggerHaptic()
                            viewModel.onNegate()
                        }
                    )
                    IosCalcButton(
                        text = "%",
                        buttonType = IosButtonType.FUNCTION,
                        modifier = Modifier.weight(1f),
                        testTag = "btn_percent",
                        onClick = {
                            triggerHaptic()
                            viewModel.onPercent()
                        }
                    )
                    IosCalcButton(
                        text = "÷",
                        buttonType = IosButtonType.OPERATOR,
                        isSelected = state.activeOperator == "÷",
                        modifier = Modifier.weight(1f),
                        testTag = "btn_divide",
                        onClick = {
                            triggerHaptic()
                            viewModel.onOperator("÷")
                        }
                    )
                }

                // Row 2: 7, 8, 9, ×
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(buttonSpacing)
                ) {
                    IosCalcButton(text = "7", buttonType = IosButtonType.NUMBER, modifier = Modifier.weight(1f), testTag = "btn_7", onClick = { triggerHaptic(); viewModel.onDigit("7") })
                    IosCalcButton(text = "8", buttonType = IosButtonType.NUMBER, modifier = Modifier.weight(1f), testTag = "btn_8", onClick = { triggerHaptic(); viewModel.onDigit("8") })
                    IosCalcButton(text = "9", buttonType = IosButtonType.NUMBER, modifier = Modifier.weight(1f), testTag = "btn_9", onClick = { triggerHaptic(); viewModel.onDigit("9") })
                    IosCalcButton(
                        text = "×",
                        buttonType = IosButtonType.OPERATOR,
                        isSelected = state.activeOperator == "×",
                        modifier = Modifier.weight(1f),
                        testTag = "btn_multiply",
                        onClick = {
                            triggerHaptic()
                            viewModel.onOperator("×")
                        }
                    )
                }

                // Row 3: 4, 5, 6, −
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(buttonSpacing)
                ) {
                    IosCalcButton(text = "4", buttonType = IosButtonType.NUMBER, modifier = Modifier.weight(1f), testTag = "btn_4", onClick = { triggerHaptic(); viewModel.onDigit("4") })
                    IosCalcButton(text = "5", buttonType = IosButtonType.NUMBER, modifier = Modifier.weight(1f), testTag = "btn_5", onClick = { triggerHaptic(); viewModel.onDigit("5") })
                    IosCalcButton(text = "6", buttonType = IosButtonType.NUMBER, modifier = Modifier.weight(1f), testTag = "btn_6", onClick = { triggerHaptic(); viewModel.onDigit("6") })
                    IosCalcButton(
                        text = "−",
                        buttonType = IosButtonType.OPERATOR,
                        isSelected = state.activeOperator == "−",
                        modifier = Modifier.weight(1f),
                        testTag = "btn_subtract",
                        onClick = {
                            triggerHaptic()
                            viewModel.onOperator("−")
                        }
                    )
                }

                // Row 4: 1, 2, 3, +
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(buttonSpacing)
                ) {
                    IosCalcButton(text = "1", buttonType = IosButtonType.NUMBER, modifier = Modifier.weight(1f), testTag = "btn_1", onClick = { triggerHaptic(); viewModel.onDigit("1") })
                    IosCalcButton(text = "2", buttonType = IosButtonType.NUMBER, modifier = Modifier.weight(1f), testTag = "btn_2", onClick = { triggerHaptic(); viewModel.onDigit("2") })
                    IosCalcButton(text = "3", buttonType = IosButtonType.NUMBER, modifier = Modifier.weight(1f), testTag = "btn_3", onClick = { triggerHaptic(); viewModel.onDigit("3") })
                    IosCalcButton(
                        text = "+",
                        buttonType = IosButtonType.OPERATOR,
                        isSelected = state.activeOperator == "+",
                        modifier = Modifier.weight(1f),
                        testTag = "btn_add",
                        onClick = {
                            triggerHaptic()
                            viewModel.onOperator("+")
                        }
                    )
                }

                // Row 5: 0 (wide pill button spanning 2 columns), ., =
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(buttonSpacing)
                ) {
                    // Wide 0 button (weight 2f plus spacing compensation)
                    IosZeroButton(
                        modifier = Modifier.weight(2f),
                        testTag = "btn_0",
                        onClick = {
                            triggerHaptic()
                            viewModel.onDigit("0")
                        }
                    )
                    IosCalcButton(
                        text = ".",
                        buttonType = IosButtonType.NUMBER,
                        modifier = Modifier.weight(1f),
                        testTag = "btn_decimal",
                        onClick = {
                            triggerHaptic()
                            viewModel.onDecimal()
                        }
                    )
                    IosCalcButton(
                        text = "=",
                        buttonType = IosButtonType.OPERATOR,
                        modifier = Modifier.weight(1f),
                        testTag = "btn_equals",
                        onClick = {
                            triggerHaptic()
                            viewModel.onEquals()
                        }
                    )
                }
            }
        }
    }

    // History Bottom Sheet
    if (showHistorySheet) {
        ModalBottomSheet(
            onDismissRequest = { showHistorySheet = false },
            sheetState = sheetState,
            containerColor = Color(0xFF1C1C1E)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Calculation History",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = IosTextWhite
                    )

                    if (state.history.isNotEmpty()) {
                        TextButton(
                            onClick = {
                                triggerHaptic()
                                viewModel.clearHistory()
                            },
                            modifier = Modifier.testTag("clear_history_button")
                        ) {
                            Icon(
                                Icons.Default.DeleteOutline,
                                contentDescription = "Clear history",
                                tint = IosOperatorOrange,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.size(4.dp))
                            Text("Clear", color = IosOperatorOrange)
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                if (state.history.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No calculations yet",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF8E8E93)
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(state.history) { item ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        triggerHaptic()
                                        viewModel.onSelectHistoryItem(item)
                                        showHistorySheet = false
                                    },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = Color(0xFF2C2C2E)
                                )
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalAlignment = Alignment.End
                                ) {
                                    Text(
                                        text = item.expression,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color(0xFF8E8E93)
                                    )
                                    Text(
                                        text = "= ${item.result}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = IosOperatorOrange
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

enum class IosButtonType {
    NUMBER,
    OPERATOR,
    FUNCTION
}

@Composable
private fun IosCalcButton(
    text: String,
    buttonType: IosButtonType,
    isSelected: Boolean = false,
    modifier: Modifier = Modifier,
    testTag: String = "",
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.94f else 1.0f,
        label = "button_scale"
    )

    // In iOS: active operator inverts (white background, orange text)
    val containerColor = when {
        buttonType == IosButtonType.OPERATOR && isSelected -> IosOperatorActiveWhite
        buttonType == IosButtonType.OPERATOR && isPressed -> IosOperatorPressed
        buttonType == IosButtonType.OPERATOR -> IosOperatorOrange
        buttonType == IosButtonType.FUNCTION && isPressed -> IosFunctionLightGrayPressed
        buttonType == IosButtonType.FUNCTION -> IosFunctionLightGray
        isPressed -> IosNumberGrayPressed
        else -> IosNumberGray
    }

    val contentColor = when {
        buttonType == IosButtonType.OPERATOR && isSelected -> IosOperatorOrange
        buttonType == IosButtonType.FUNCTION -> IosTextDark
        else -> IosTextWhite
    }

    Surface(
        onClick = onClick,
        interactionSource = interactionSource,
        modifier = modifier
            .aspectRatio(1f)
            .scale(scale)
            .clip(CircleShape)
            .testTag(testTag),
        color = containerColor,
        contentColor = contentColor,
        shape = CircleShape
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxSize()
        ) {
            Text(
                text = text,
                fontSize = if (text.length > 2) 26.sp else 34.sp,
                fontWeight = if (buttonType == IosButtonType.OPERATOR) FontWeight.Medium else FontWeight.Normal
            )
        }
    }
}

@Composable
private fun IosZeroButton(
    modifier: Modifier = Modifier,
    testTag: String = "",
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1.0f,
        label = "zero_scale"
    )

    val containerColor = if (isPressed) IosNumberGrayPressed else IosNumberGray

    Surface(
        onClick = onClick,
        interactionSource = interactionSource,
        modifier = modifier
            .aspectRatio(2.15f)
            .scale(scale)
            .clip(CircleShape)
            .testTag(testTag),
        color = containerColor,
        contentColor = IosTextWhite,
        shape = CircleShape
    ) {
        Box(
            contentAlignment = Alignment.CenterStart,
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 28.dp)
        ) {
            Text(
                text = "0",
                fontSize = 34.sp,
                fontWeight = FontWeight.Normal
            )
        }
    }
}


