package com.example.ui.stopwatch

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LapRecord
import com.example.model.StopwatchFormatter
import com.example.model.StopwatchStatus
import com.example.viewmodel.StopwatchUiState
import com.example.viewmodel.StopwatchViewModel

@Composable
fun StopwatchScreen(
    viewModel: StopwatchViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Header
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = "Stopwatch",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "High-precision timer with split lap tracking",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Circular / Oval Timer Dial Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.5f)
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 32.dp, horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Status Badge
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = when (state.status) {
                        StopwatchStatus.RUNNING -> MaterialTheme.colorScheme.primaryContainer
                        StopwatchStatus.PAUSED -> MaterialTheme.colorScheme.tertiaryContainer
                        StopwatchStatus.IDLE -> MaterialTheme.colorScheme.surfaceVariant
                    },
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Text(
                        text = when (state.status) {
                            StopwatchStatus.RUNNING -> "● RUNNING"
                            StopwatchStatus.PAUSED -> "❚❚ PAUSED"
                            StopwatchStatus.IDLE -> "READY"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when (state.status) {
                            StopwatchStatus.RUNNING -> MaterialTheme.colorScheme.onPrimaryContainer
                            StopwatchStatus.PAUSED -> MaterialTheme.colorScheme.onTertiaryContainer
                            StopwatchStatus.IDLE -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                // Large clearly visible time display
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.testTag("stopwatch_display")
                ) {
                    Text(
                        text = state.formattedTime.primaryDigits,
                        style = MaterialTheme.typography.displayLarge.copy(fontSize = 54.sp),
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = state.formattedTime.fractionDigits,
                        style = MaterialTheme.typography.headlineMedium.copy(fontSize = 28.sp),
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }

                Text(
                    text = if (state.formattedTime.hours > 0) "HOURS : MINUTES : SECONDS . CS" else "MINUTES : SECONDS . CENTISECONDS",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }

        // Control Buttons Row (Start, Stop/Pause, Reset, Lap)
        // Buttons visually change state according to Task 5 requirements
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Reset Button: stops timer and resets display to 00:00:00
            val isResetEnabled = state.elapsedMillis > 0L && state.status != StopwatchStatus.RUNNING
            OutlinedButton(
                onClick = { viewModel.reset() },
                enabled = isResetEnabled,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp)
                    .testTag("stopwatch_reset_button")
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Reset timer", modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(4.dp))
                Text("Reset")
            }

            // Lap Button: records current time to scrollable list (enabled only when running)
            val isLapEnabled = state.status == StopwatchStatus.RUNNING
            FilledTonalButton(
                onClick = { viewModel.recordLap() },
                enabled = isLapEnabled,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp)
                    .testTag("stopwatch_lap_button")
            ) {
                Icon(Icons.Default.Flag, contentDescription = "Record lap", modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(4.dp))
                Text("Lap")
            }

            // Primary Start / Stop / Pause Button
            // Visually changes state:
            // - When RUNNING: becomes active Pause/Stop button
            // - When PAUSED: becomes Resume button
            // - When IDLE: becomes Start button
            when (state.status) {
                StopwatchStatus.RUNNING -> {
                    Button(
                        onClick = { viewModel.pause() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(54.dp)
                            .testTag("stopwatch_pause_button")
                    ) {
                        Icon(Icons.Default.Pause, contentDescription = "Pause timer")
                        Spacer(Modifier.width(6.dp))
                        Text("Pause", fontWeight = FontWeight.Bold)
                    }
                }
                StopwatchStatus.PAUSED -> {
                    Button(
                        onClick = { viewModel.resume() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(54.dp)
                            .testTag("stopwatch_resume_button")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Resume timer")
                        Spacer(Modifier.width(6.dp))
                        Text("Resume", fontWeight = FontWeight.Bold)
                    }
                }
                StopwatchStatus.IDLE -> {
                    Button(
                        onClick = { viewModel.start() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(54.dp)
                            .testTag("stopwatch_start_button")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Start timer")
                        Spacer(Modifier.width(6.dp))
                        Text("Start", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Laps Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LAPS RECORDED (${state.laps.size})",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
                if (state.laps.isNotEmpty()) {
                    Text(
                        text = "Split / Total",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (state.laps.isEmpty()) {
                // Empty state
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.3f))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(40.dp)
                        )
                        Text(
                            text = "No laps recorded yet",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Tap 'Lap' while running to capture split times",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.3f))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(state.laps, key = { it.lapNumber }) { lap ->
                        val isFastest = lap.lapNumber == state.fastestLapNumber
                        val isSlowest = lap.lapNumber == state.slowestLapNumber

                        LapItemRow(
                            lap = lap,
                            isFastest = isFastest,
                            isSlowest = isSlowest
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LapItemRow(
    lap: LapRecord,
    isFastest: Boolean,
    isSlowest: Boolean,
    modifier: Modifier = Modifier
) {
    val lapSplitFormatted = StopwatchFormatter.formatTime(lap.lapTimeMillis)
    val totalFormatted = StopwatchFormatter.formatTime(lap.totalTimeMillis)

    val textColor = when {
        isFastest -> Color(0xFF10B981) // Green
        isSlowest -> Color(0xFFF59E0B) // Amber
        else -> MaterialTheme.colorScheme.onSurface
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("lap_item_${lap.lapNumber}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = String.format("Lap %02d", lap.lapNumber),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = textColor
                )

                if (isFastest) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFF10B981).copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "FASTEST",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF10B981),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                } else if (isSlowest) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFF59E0B).copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "SLOWEST",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFF59E0B),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Lap split time
                Text(
                    text = "+${lapSplitFormatted.fullDisplay}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace,
                    color = textColor
                )

                // Total elapsed at lap
                Text(
                    text = totalFormatted.fullDisplay,
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
