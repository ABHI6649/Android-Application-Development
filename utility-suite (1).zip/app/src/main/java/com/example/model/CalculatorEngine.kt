package com.example.model

import java.text.DecimalFormat
import java.util.Stack

data class CalculationHistoryItem(
    val expression: String,
    val result: String,
    val timestamp: Long = System.currentTimeMillis()
)

object CalculatorEngine {

    /**
     * Evaluates a mathematical expression string containing numbers, +, -, *, /, %, (, ).
     * Returns a Result with the formatted number string or throws an exception/error description.
     */
    fun evaluate(expression: String): Result<String> {
        val sanitized = expression
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")
            .replace(" ", "")

        if (sanitized.isEmpty()) {
            return Result.failure(IllegalArgumentException("Empty expression"))
        }

        return try {
            val tokens = tokenize(sanitized)
            val postfix = infixToPostfix(tokens)
            val result = evaluatePostfix(postfix)

            if (result.isInfinite() || result.isNaN()) {
                Result.failure(ArithmeticException("Error: Division by zero"))
            } else {
                Result.success(formatNumber(result))
            }
        } catch (e: ArithmeticException) {
            Result.failure(e)
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("Invalid expression"))
        }
    }

    private fun tokenize(expr: String): List<String> {
        val tokens = mutableListOf<String>()
        var i = 0
        val len = expr.length

        while (i < len) {
            val c = expr[i]

            // Check if '-' is unary minus (e.g. at start or after an operator or '(')
            if (c == '-' && (tokens.isEmpty() || isOperator(tokens.last()) || tokens.last() == "(")) {
                // Parse negative number
                val sb = java.lang.StringBuilder("-")
                i++
                while (i < len && (expr[i].isDigit() || expr[i] == '.')) {
                    sb.append(expr[i])
                    i++
                }
                if (sb.length == 1) {
                    // Just a unary minus operator before bracket, treat as -1 *
                    tokens.add("-1")
                    tokens.add("*")
                } else {
                    tokens.add(sb.toString())
                }
                continue
            }

            if (c.isDigit() || c == '.') {
                val sb = java.lang.StringBuilder()
                while (i < len && (expr[i].isDigit() || expr[i] == '.')) {
                    sb.append(expr[i])
                    i++
                }
                tokens.add(sb.toString())
                continue
            }

            if (c == '+' || c == '-' || c == '*' || c == '/' || c == '%' || c == '(' || c == ')') {
                tokens.add(c.toString())
                i++
                continue
            }

            // Skip unknown characters
            i++
        }

        return tokens
    }

    private fun isOperator(token: String): Boolean {
        return token == "+" || token == "-" || token == "*" || token == "/" || token == "%"
    }

    private fun precedence(op: String): Int {
        return when (op) {
            "+", "-" -> 1
            "*", "/", "%" -> 2
            else -> 0
        }
    }

    private fun infixToPostfix(tokens: List<String>): List<String> {
        val output = mutableListOf<String>()
        val stack = Stack<String>()

        for (token in tokens) {
            when {
                token.toDoubleOrNull() != null -> {
                    output.add(token)
                }
                token == "(" -> {
                    stack.push(token)
                }
                token == ")" -> {
                    while (stack.isNotEmpty() && stack.peek() != "(") {
                        output.add(stack.pop())
                    }
                    if (stack.isNotEmpty() && stack.peek() == "(") {
                        stack.pop()
                    }
                }
                isOperator(token) -> {
                    while (stack.isNotEmpty() && stack.peek() != "(" && precedence(stack.peek()) >= precedence(token)) {
                        output.add(stack.pop())
                    }
                    stack.push(token)
                }
            }
        }

        while (stack.isNotEmpty()) {
            val top = stack.pop()
            if (top != "(" && top != ")") {
                output.add(top)
            }
        }

        return output
    }

    private fun evaluatePostfix(postfix: List<String>): Double {
        val stack = Stack<Double>()

        for (token in postfix) {
            val number = token.toDoubleOrNull()
            if (number != null) {
                stack.push(number)
            } else if (isOperator(token)) {
                if (stack.size < 2) throw IllegalArgumentException("Malformed expression")
                val b = stack.pop()
                val a = stack.pop()

                val res = when (token) {
                    "+" -> a + b
                    "-" -> a - b
                    "*" -> a * b
                    "/" -> {
                        if (Math.abs(b) < 1e-12) {
                            throw ArithmeticException("Division by zero")
                        }
                        a / b
                    }
                    "%" -> {
                        if (Math.abs(b) < 1e-12) {
                            throw ArithmeticException("Modulo by zero")
                        }
                        a % b
                    }
                    else -> throw IllegalArgumentException("Unknown operator: $token")
                }
                stack.push(res)
            }
        }

        if (stack.size != 1) throw IllegalArgumentException("Malformed expression")
        return stack.pop()
    }

    fun formatNumber(value: Double): String {
        return if (value.isInfinite() || value.isNaN()) {
            "Error"
        } else if (value == Math.floor(value) && !value.isInfinite() && Math.abs(value) < 1e12) {
            value.toLong().toString()
        } else if (Math.abs(value) >= 1e10 || (Math.abs(value) > 0 && Math.abs(value) < 1e-6)) {
            DecimalFormat("0.######E0").format(value)
        } else {
            val df = DecimalFormat("#,##0.########")
            df.format(value)
        }
    }
}
