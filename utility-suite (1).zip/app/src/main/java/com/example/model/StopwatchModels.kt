package com.example.model

import java.util.Locale

enum class StopwatchStatus {
    IDLE,
    RUNNING,
    PAUSED
}

data class LapRecord(
    val lapNumber: Int,
    val lapTimeMillis: Long,
    val totalTimeMillis: Long
)

object StopwatchFormatter {
    /**
     * Formats milliseconds into [HH:]MM:SS.cs (centiseconds).
     */
    fun formatTime(timeMillis: Long, includeHoursAlways: Boolean = false): FormattedTime {
        val totalCentis = timeMillis / 10
        val centis = (totalCentis % 100).toInt()
        val totalSeconds = timeMillis / 1000
        val seconds = (totalSeconds % 60).toInt()
        val totalMinutes = totalSeconds / 60
        val minutes = (totalMinutes % 60).toInt()
        val hours = (totalMinutes / 60).toInt()

        val mainText = if (hours > 0 || includeHoursAlways) {
            String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
        val centisText = String.format(Locale.US, ".%02d", centis)

        return FormattedTime(
            hours = hours,
            minutes = minutes,
            seconds = seconds,
            centis = centis,
            fullDisplay = "$mainText$centisText",
            primaryDigits = mainText,
            fractionDigits = centisText
        )
    }
}

data class FormattedTime(
    val hours: Int,
    val minutes: Int,
    val seconds: Int,
    val centis: Int,
    val fullDisplay: String,
    val primaryDigits: String,
    val fractionDigits: String
)
