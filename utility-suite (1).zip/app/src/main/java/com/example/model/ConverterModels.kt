package com.example.model

import java.text.DecimalFormat

enum class UnitCategory(val displayName: String, val iconName: String) {
    LENGTH("Length", "straighten"),
    WEIGHT("Weight", "scale"),
    VOLUME("Volume", "local_drink"),
    TEMPERATURE("Temperature", "thermostat"),
    SPEED("Speed", "speed"),
    AREA("Area", "crop_square"),
    DATA("Data Storage", "memory")
}

data class ConversionUnit(
    val id: String,
    val name: String,
    val symbol: String,
    val category: UnitCategory,
    val factorToBase: Double = 1.0 // Factor to convert this unit into the base unit
)

object UnitRepository {
    val unitsByCategory: Map<UnitCategory, List<ConversionUnit>> = mapOf(
        UnitCategory.LENGTH to listOf(
            ConversionUnit("cm", "Centimetres", "cm", UnitCategory.LENGTH, 0.01),
            ConversionUnit("m", "Metres", "m", UnitCategory.LENGTH, 1.0),
            ConversionUnit("km", "Kilometres", "km", UnitCategory.LENGTH, 1000.0),
            ConversionUnit("mm", "Millimetres", "mm", UnitCategory.LENGTH, 0.001),
            ConversionUnit("in", "Inches", "in", UnitCategory.LENGTH, 0.0254),
            ConversionUnit("ft", "Feet", "ft", UnitCategory.LENGTH, 0.3048),
            ConversionUnit("yd", "Yards", "yd", UnitCategory.LENGTH, 0.9144),
            ConversionUnit("mi", "Miles", "mi", UnitCategory.LENGTH, 1609.344),
            ConversionUnit("nmi", "Nautical Miles", "nmi", UnitCategory.LENGTH, 1852.0)
        ),
        UnitCategory.WEIGHT to listOf(
            ConversionUnit("g", "Grams", "g", UnitCategory.WEIGHT, 0.001),
            ConversionUnit("kg", "Kilograms", "kg", UnitCategory.WEIGHT, 1.0),
            ConversionUnit("mg", "Milligrams", "mg", UnitCategory.WEIGHT, 0.000001),
            ConversionUnit("lb", "Pounds", "lb", UnitCategory.WEIGHT, 0.45359237),
            ConversionUnit("oz", "Ounces", "oz", UnitCategory.WEIGHT, 0.028349523125),
            ConversionUnit("st", "Stones", "st", UnitCategory.WEIGHT, 6.35029318),
            ConversionUnit("t", "Metric Tonnes", "t", UnitCategory.WEIGHT, 1000.0)
        ),
        UnitCategory.VOLUME to listOf(
            ConversionUnit("l", "Litres", "L", UnitCategory.VOLUME, 1.0),
            ConversionUnit("ml", "Millilitres", "mL", UnitCategory.VOLUME, 0.001),
            ConversionUnit("m3", "Cubic Metres", "m³", UnitCategory.VOLUME, 1000.0),
            ConversionUnit("gal", "Gallons (US)", "gal", UnitCategory.VOLUME, 3.785411784),
            ConversionUnit("impgal", "Gallons (UK/Imp)", "imp gal", UnitCategory.VOLUME, 4.54609),
            ConversionUnit("qt", "Quarts (US)", "qt", UnitCategory.VOLUME, 0.946352946),
            ConversionUnit("pt", "Pints (US)", "pt", UnitCategory.VOLUME, 0.473176473),
            ConversionUnit("cup", "Cups (US)", "cup", UnitCategory.VOLUME, 0.2365882365),
            ConversionUnit("floz", "Fluid Ounces (US)", "fl oz", UnitCategory.VOLUME, 0.0295735295625)
        ),
        UnitCategory.TEMPERATURE to listOf(
            ConversionUnit("c", "Celsius", "°C", UnitCategory.TEMPERATURE),
            ConversionUnit("f", "Fahrenheit", "°F", UnitCategory.TEMPERATURE),
            ConversionUnit("k", "Kelvin", "K", UnitCategory.TEMPERATURE)
        ),
        UnitCategory.SPEED to listOf(
            ConversionUnit("kmh", "Kilometres / hour", "km/h", UnitCategory.SPEED, 1.0 / 3.6),
            ConversionUnit("ms", "Metres / second", "m/s", UnitCategory.SPEED, 1.0),
            ConversionUnit("mph", "Miles / hour", "mph", UnitCategory.SPEED, 0.44704),
            ConversionUnit("knot", "Knots", "kn", UnitCategory.SPEED, 0.51444444),
            ConversionUnit("fts", "Feet / second", "ft/s", UnitCategory.SPEED, 0.3048)
        ),
        UnitCategory.AREA to listOf(
            ConversionUnit("sqm", "Square Metres", "m²", UnitCategory.AREA, 1.0),
            ConversionUnit("sqkm", "Square Kilometres", "km²", UnitCategory.AREA, 1_000_000.0),
            ConversionUnit("sqft", "Square Feet", "sq ft", UnitCategory.AREA, 0.09290304),
            ConversionUnit("sqyd", "Square Yards", "sq yd", UnitCategory.AREA, 0.83612736),
            ConversionUnit("acre", "Acres", "ac", UnitCategory.AREA, 4046.8564224),
            ConversionUnit("ha", "Hectares", "ha", UnitCategory.AREA, 10000.0)
        ),
        UnitCategory.DATA to listOf(
            ConversionUnit("b", "Bytes", "B", UnitCategory.DATA, 1.0),
            ConversionUnit("kb", "Kilobytes (KB)", "KB", UnitCategory.DATA, 1024.0),
            ConversionUnit("mb", "Megabytes (MB)", "MB", UnitCategory.DATA, 1048576.0),
            ConversionUnit("gb", "Gigabytes (GB)", "GB", UnitCategory.DATA, 1073741824.0),
            ConversionUnit("tb", "Terabytes (TB)", "TB", UnitCategory.DATA, 1099511627776.0)
        )
    )

    fun convert(
        value: Double,
        from: ConversionUnit,
        to: ConversionUnit
    ): Double {
        if (from.id == to.id) return value

        if (from.category == UnitCategory.TEMPERATURE) {
            // Convert 'from' to Kelvin base
            val inKelvin = when (from.id) {
                "c" -> value + 273.15
                "f" -> (value - 32.0) * (5.0 / 9.0) + 273.15
                "k" -> value
                else -> value
            }
            // Convert Kelvin to 'to'
            return when (to.id) {
                "c" -> inKelvin - 273.15
                "f" -> (inKelvin - 273.15) * (9.0 / 5.0) + 32.0
                "k" -> inKelvin
                else -> inKelvin
            }
        }

        // Standard ratio conversion: value * from.factorToBase / to.factorToBase
        val inBase = value * from.factorToBase
        return inBase / to.factorToBase
    }

    fun formatResult(value: Double): String {
        return if (value.isNaN() || value.isInfinite()) {
            "Error"
        } else if (Math.abs(value) >= 1e8 || (Math.abs(value) > 0 && Math.abs(value) < 1e-4)) {
            DecimalFormat("0.####E0").format(value)
        } else {
            val df = DecimalFormat("#,##0.######")
            df.format(value)
        }
    }
}
