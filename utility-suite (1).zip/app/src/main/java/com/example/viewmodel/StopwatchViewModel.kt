package com.example.viewmodel

import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.FormattedTime
import com.example.model.LapRecord
import com.example.model.StopwatchFormatter
import com.example.model.StopwatchStatus
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class StopwatchUiState(
    val status: StopwatchStatus = StopwatchStatus.IDLE,
    val elapsedMillis: Long = 0L,
    val formattedTime: FormattedTime = StopwatchFormatter.formatTime(0L),
    val laps: List<LapRecord> = emptyList(),
    val fastestLapNumber: Int? = null,
    val slowestLapNumber: Int? = null
)

class StopwatchViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(StopwatchUiState())
    val uiState: StateFlow<StopwatchUiState> = _uiState.asStateFlow()

    private var tickerJob: Job? = null
    private var baseStartTime: Long = 0L
    private var accumulatedBeforePause: Long = 0L
    private var lastLapTotalMillis: Long = 0L

    fun start() {
        if (_uiState.value.status == StopwatchStatus.RUNNING) return

        baseStartTime = SystemClock.elapsedRealtime()
        _uiState.update { it.copy(status = StopwatchStatus.RUNNING) }

        startTicker()
    }

    fun pause() {
        if (_uiState.value.status != StopwatchStatus.RUNNING) return

        tickerJob?.cancel()
        tickerJob = null

        val now = SystemClock.elapsedRealtime()
        val currentSession = now - baseStartTime
        accumulatedBeforePause += currentSession

        _uiState.update {
            it.copy(
                status = StopwatchStatus.PAUSED,
                elapsedMillis = accumulatedBeforePause,
                formattedTime = StopwatchFormatter.formatTime(accumulatedBeforePause)
            )
        }
    }

    fun resume() {
        if (_uiState.value.status != StopwatchStatus.PAUSED) return
        baseStartTime = SystemClock.elapsedRealtime()
        _uiState.update { it.copy(status = StopwatchStatus.RUNNING) }
        startTicker()
    }

    fun reset() {
        tickerJob?.cancel()
        tickerJob = null

        baseStartTime = 0L
        accumulatedBeforePause = 0L
        lastLapTotalMillis = 0L

        _uiState.update {
            StopwatchUiState()
        }
    }

    fun recordLap() {
        val state = _uiState.value
        if (state.status != StopwatchStatus.RUNNING) return

        val total = state.elapsedMillis
        val lapDelta = total - lastLapTotalMillis
        lastLapTotalMillis = total

        val newLap = LapRecord(
            lapNumber = state.laps.size + 1,
            lapTimeMillis = lapDelta,
            totalTimeMillis = total
        )

        val updatedLaps = listOf(newLap) + state.laps
        val (fastest, slowest) = computeFastestAndSlowest(updatedLaps)

        _uiState.update {
            it.copy(
                laps = updatedLaps,
                fastestLapNumber = fastest,
                slowestLapNumber = slowest
            )
        }
    }

    private fun computeFastestAndSlowest(laps: List<LapRecord>): Pair<Int?, Int?> {
        if (laps.size < 2) return Pair(null, null)
        val min = laps.minByOrNull { it.lapTimeMillis }
        val max = laps.maxByOrNull { it.lapTimeMillis }
        return Pair(min?.lapNumber, max?.lapNumber)
    }

    private fun startTicker() {
        tickerJob?.cancel()
        tickerJob = viewModelScope.launch {
            while (isActive) {
                val now = SystemClock.elapsedRealtime()
                val totalElapsed = accumulatedBeforePause + (now - baseStartTime)
                _uiState.update {
                    it.copy(
                        elapsedMillis = totalElapsed,
                        formattedTime = StopwatchFormatter.formatTime(totalElapsed)
                    )
                }
                delay(16) // ~60fps smooth refresh
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        tickerJob?.cancel()
    }
}
