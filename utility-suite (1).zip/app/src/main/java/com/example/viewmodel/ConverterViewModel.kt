package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.model.ConversionUnit
import com.example.model.UnitCategory
import com.example.model.UnitRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class ConverterUiState(
    val selectedCategory: UnitCategory = UnitCategory.LENGTH,
    val availableUnits: List<ConversionUnit> = UnitRepository.unitsByCategory[UnitCategory.LENGTH] ?: emptyList(),
    val sourceUnit: ConversionUnit = UnitRepository.unitsByCategory[UnitCategory.LENGTH]?.get(0)
        ?: ConversionUnit("cm", "Centimetres", "cm", UnitCategory.LENGTH),
    val targetUnit: ConversionUnit = UnitRepository.unitsByCategory[UnitCategory.LENGTH]?.get(1)
        ?: ConversionUnit("m", "Metres", "m", UnitCategory.LENGTH),
    val inputValue: String = "1",
    val resultText: String = "",
    val resultFormatted: String = "",
    val conversionExplanation: String = "",
    val errorMessage: String? = null
)

sealed interface ConverterEvent {
    data class ShowToast(val message: String) : ConverterEvent
    data class CopiedToClipboard(val text: String) : ConverterEvent
}

class ConverterViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(ConverterUiState())
    val uiState: StateFlow<ConverterUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<ConverterEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<ConverterEvent> = _events.asSharedFlow()

    init {
        // Initial conversion with default "1"
        computeConversion(showToastOnError = false)
    }

    fun onCategorySelected(category: UnitCategory) {
        val units = UnitRepository.unitsByCategory[category] ?: return
        val defaultSource = units.firstOrNull() ?: return
        val defaultTarget = units.getOrNull(1) ?: defaultSource

        _uiState.update {
            it.copy(
                selectedCategory = category,
                availableUnits = units,
                sourceUnit = defaultSource,
                targetUnit = defaultTarget,
                errorMessage = null
            )
        }
        computeConversion(showToastOnError = false)
    }

    fun onSourceUnitSelected(unit: ConversionUnit) {
        _uiState.update { it.copy(sourceUnit = unit) }
        computeConversion(showToastOnError = false)
    }

    fun onTargetUnitSelected(unit: ConversionUnit) {
        _uiState.update { it.copy(targetUnit = unit) }
        computeConversion(showToastOnError = false)
    }

    fun onInputValueChanged(newValue: String) {
        // Normalize comma to dot for international users while typing
        val normalized = newValue.replace(',', '.')
        // Allow digits, single decimal point, and optional leading minus for temperature
        val filtered = if (_uiState.value.selectedCategory == UnitCategory.TEMPERATURE) {
            normalized.filterIndexed { index, c ->
                c.isDigit() || (c == '.' && normalized.indexOf('.') == index) || (c == '-' && index == 0)
            }
        } else {
            normalized.filterIndexed { index, c ->
                c.isDigit() || (c == '.' && normalized.indexOf('.') == index)
            }
        }

        _uiState.update { it.copy(inputValue = filtered, errorMessage = null) }
        // Compute live preview if valid
        if (filtered.isNotEmpty() && filtered != "-" && filtered != ".") {
            computeConversion(showToastOnError = false)
        } else {
            _uiState.update {
                it.copy(
                    resultText = "",
                    resultFormatted = "",
                    conversionExplanation = ""
                )
            }
        }
    }

    fun swapUnits() {
        val currentSource = _uiState.value.sourceUnit
        val currentTarget = _uiState.value.targetUnit
        _uiState.update {
            it.copy(
                sourceUnit = currentTarget,
                targetUnit = currentSource
            )
        }
        computeConversion(showToastOnError = false)
    }

    fun onConvertClicked() {
        computeConversion(showToastOnError = true)
    }

    private fun computeConversion(showToastOnError: Boolean) {
        val state = _uiState.value
        val raw = state.inputValue.trim().replace(',', '.')

        if (raw.isEmpty()) {
            val msg = "Please enter a numeric value to convert"
            _uiState.update {
                it.copy(
                    errorMessage = msg,
                    resultText = "",
                    resultFormatted = "",
                    conversionExplanation = ""
                )
            }
            if (showToastOnError) {
                _events.tryEmit(ConverterEvent.ShowToast(msg))
            }
            return
        }

        val numeric = raw.toDoubleOrNull()
        if (numeric == null || raw == "-" || raw == ".") {
            val msg = "Please enter a valid numeric value"
            _uiState.update {
                it.copy(
                    errorMessage = msg,
                    resultText = "",
                    resultFormatted = "",
                    conversionExplanation = ""
                )
            }
            if (showToastOnError) {
                _events.tryEmit(ConverterEvent.ShowToast(msg))
            }
            return
        }

        try {
            val converted = UnitRepository.convert(numeric, state.sourceUnit, state.targetUnit)
            val formattedResult = UnitRepository.formatResult(converted)
            val fullResultText = "$formattedResult ${state.targetUnit.symbol}"

            // Generate conversion rate explanation
            val sampleOneConversion = UnitRepository.convert(1.0, state.sourceUnit, state.targetUnit)
            val explanation = if (state.selectedCategory == UnitCategory.TEMPERATURE) {
                when {
                    state.sourceUnit.id == "c" && state.targetUnit.id == "f" -> "(°C × 9/5) + 32 = °F"
                    state.sourceUnit.id == "f" && state.targetUnit.id == "c" -> "(°F − 32) × 5/9 = °C"
                    state.sourceUnit.id == "c" && state.targetUnit.id == "k" -> "°C + 273.15 = K"
                    state.sourceUnit.id == "k" && state.targetUnit.id == "c" -> "K − 273.15 = °C"
                    else -> "1 ${state.sourceUnit.symbol} = ${UnitRepository.formatResult(sampleOneConversion)} ${state.targetUnit.symbol}"
                }
            } else {
                "1 ${state.sourceUnit.symbol} = ${UnitRepository.formatResult(sampleOneConversion)} ${state.targetUnit.symbol}"
            }

            _uiState.update {
                it.copy(
                    resultText = fullResultText,
                    resultFormatted = formattedResult,
                    conversionExplanation = explanation,
                    errorMessage = null
                )
            }
        } catch (e: Exception) {
            val msg = "Conversion error: ${e.message}"
            _uiState.update { it.copy(errorMessage = msg) }
            if (showToastOnError) {
                _events.tryEmit(ConverterEvent.ShowToast(msg))
            }
        }
    }
}
