package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.model.CalculationHistoryItem
import com.example.model.CalculatorEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class CalculatorUiState(
    val expression: String = "",
    val previewResult: String = "",
    val isEvaluated: Boolean = false,
    val hasError: Boolean = false,
    val errorMessage: String = "",
    val activeOperator: String? = null,
    val history: List<CalculationHistoryItem> = emptyList()
)

class CalculatorViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(CalculatorUiState())
    val uiState: StateFlow<CalculatorUiState> = _uiState.asStateFlow()

    fun onDigit(digit: String) {
        _uiState.update { state ->
            if (state.hasError || state.isEvaluated) {
                state.copy(
                    expression = digit,
                    previewResult = "",
                    isEvaluated = false,
                    hasError = false,
                    errorMessage = "",
                    activeOperator = null
                )
            } else {
                val newExpr = state.expression + digit
                state.copy(
                    expression = newExpr,
                    previewResult = calculatePreview(newExpr),
                    activeOperator = null
                )
            }
        }
    }

    fun onDecimal() {
        _uiState.update { state ->
            if (state.hasError || state.isEvaluated) {
                state.copy(
                    expression = "0.",
                    previewResult = "",
                    isEvaluated = false,
                    hasError = false,
                    activeOperator = null
                )
            } else {
                val expr = state.expression
                val lastNumber = expr.split("+", "−", "×", "÷", "(", ")").lastOrNull() ?: ""
                if (!lastNumber.contains(".")) {
                    val append = if (expr.isEmpty() || isOperatorChar(expr.last()) || expr.last() == '(') "0." else "."
                    val newExpr = expr + append
                    state.copy(
                        expression = newExpr,
                        previewResult = calculatePreview(newExpr),
                        activeOperator = null
                    )
                } else {
                    state
                }
            }
        }
    }

    fun onOperator(op: String) {
        _uiState.update { state ->
            if (state.hasError) {
                state
            } else {
                var expr = state.expression
                if (state.isEvaluated && state.previewResult.isNotEmpty() && state.previewResult != "Error") {
                    expr = state.previewResult
                }

                if (expr.isEmpty()) {
                    if (op == "−") {
                        state.copy(expression = "−", isEvaluated = false, activeOperator = op)
                    } else {
                        state
                    }
                } else {
                    val lastChar = expr.last().toString()
                    val newExpr = if (isOperatorChar(lastChar.first())) {
                        // Replace last operator
                        expr.dropLast(1) + op
                    } else {
                        expr + op
                    }
                    state.copy(
                        expression = newExpr,
                        isEvaluated = false,
                        activeOperator = op
                    )
                }
            }
        }
    }

    fun onParenthesis() {
        _uiState.update { state ->
            if (state.hasError || state.isEvaluated) {
                state.copy(
                    expression = "(",
                    previewResult = "",
                    isEvaluated = false,
                    hasError = false
                )
            } else {
                val expr = state.expression
                val openCount = expr.count { it == '(' }
                val closeCount = expr.count { it == ')' }

                val shouldClose = openCount > closeCount && expr.isNotEmpty() &&
                        (expr.last().isDigit() || expr.last() == ')')

                val newExpr = if (shouldClose) {
                    expr + ")"
                } else {
                    if (expr.isNotEmpty() && (expr.last().isDigit() || expr.last() == ')')) {
                        expr + "×("
                    } else {
                        expr + "("
                    }
                }
                state.copy(
                    expression = newExpr,
                    previewResult = calculatePreview(newExpr)
                )
            }
        }
    }

    fun onPercent() {
        _uiState.update { state ->
            val expr = state.expression
            if (expr.isNotEmpty() && (expr.last().isDigit() || expr.last() == ')')) {
                val newExpr = "$expr%"
                state.copy(
                    expression = newExpr,
                    previewResult = calculatePreview(newExpr)
                )
            } else {
                state
            }
        }
    }

    fun onNegate() {
        _uiState.update { state ->
            val expr = state.expression
            if (expr.isEmpty()) {
                state.copy(expression = "−")
            } else if (state.isEvaluated && state.previewResult.isNotEmpty() && state.previewResult != "Error") {
                val evaluated = state.previewResult
                val negated = if (evaluated.startsWith("-")) evaluated.drop(1) else "-$evaluated"
                state.copy(expression = negated, previewResult = "", isEvaluated = false)
            } else {
                // Find last number token and negate it
                val tokens = expr.split("(?<=[+−×÷()])|(?=[+−×÷()])".toRegex()).filter { it.isNotEmpty() }
                if (tokens.isNotEmpty()) {
                    val last = tokens.last()
                    if (last.toDoubleOrNull() != null) {
                        val prefix = expr.dropLast(last.length)
                        val toggled = if (prefix.endsWith("−")) {
                            prefix.dropLast(1) + "+" + last
                        } else if (prefix.endsWith("+")) {
                            prefix.dropLast(1) + "−" + last
                        } else {
                            prefix + "(−$last)"
                        }
                        state.copy(expression = toggled, previewResult = calculatePreview(toggled))
                    } else {
                        state
                    }
                } else {
                    state
                }
            }
        }
    }

    fun onBackspace() {
        _uiState.update { state ->
            if (state.hasError || state.isEvaluated) {
                state.copy(expression = "", previewResult = "", isEvaluated = false, hasError = false)
            } else if (state.expression.isNotEmpty()) {
                val newExpr = state.expression.dropLast(1)
                state.copy(
                    expression = newExpr,
                    previewResult = calculatePreview(newExpr)
                )
            } else {
                state
            }
        }
    }

    fun onClear() {
        _uiState.update {
            it.copy(
                expression = "",
                previewResult = "",
                isEvaluated = false,
                hasError = false,
                errorMessage = "",
                activeOperator = null
            )
        }
    }

    fun onEquals() {
        val state = _uiState.value
        val expr = state.expression.trim()
        if (expr.isEmpty()) return

        val evaluation = CalculatorEngine.evaluate(expr)
        evaluation.fold(
            onSuccess = { res ->
                val newHistory = listOf(
                    CalculationHistoryItem(expression = expr, result = res)
                ) + state.history.take(19)

                _uiState.update {
                    it.copy(
                        previewResult = res,
                        isEvaluated = true,
                        hasError = false,
                        errorMessage = "",
                        activeOperator = null,
                        history = newHistory
                    )
                }
            },
            onFailure = { err ->
                val displayMsg = if (err is ArithmeticException) "Error" else "Error"
                _uiState.update {
                    it.copy(
                        previewResult = displayMsg,
                        isEvaluated = true,
                        hasError = true,
                        errorMessage = err.message ?: "Invalid Expression",
                        activeOperator = null
                    )
                }
            }
        )
    }

    fun onSelectHistoryItem(item: CalculationHistoryItem) {
        _uiState.update {
            it.copy(
                expression = item.result,
                previewResult = "",
                isEvaluated = false,
                hasError = false,
                errorMessage = ""
            )
        }
    }

    fun clearHistory() {
        _uiState.update { it.copy(history = emptyList()) }
    }

    private fun calculatePreview(expr: String): String {
        if (expr.isEmpty()) return ""
        // Auto-close any unclosed parenthesis for preview
        val openCount = expr.count { it == '(' }
        val closeCount = expr.count { it == ')' }
        val closedExpr = expr + ")".repeat((openCount - closeCount).coerceAtLeast(0))

        val result = CalculatorEngine.evaluate(closedExpr)
        return result.getOrNull() ?: ""
    }

    private fun isOperatorChar(c: Char): Boolean {
        return c == '+' || c == '−' || c == '×' || c == '÷'
    }
}
